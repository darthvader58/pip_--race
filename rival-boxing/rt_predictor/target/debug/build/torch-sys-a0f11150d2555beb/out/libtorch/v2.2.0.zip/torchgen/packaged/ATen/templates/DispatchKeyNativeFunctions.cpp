// ${generated_comment}
${includes}
${native_functions_include}

namespace {
${helper_fns}
} // namespace

${namespace_prologue}

${native_function_definitions}

${namespace_epilogue}
