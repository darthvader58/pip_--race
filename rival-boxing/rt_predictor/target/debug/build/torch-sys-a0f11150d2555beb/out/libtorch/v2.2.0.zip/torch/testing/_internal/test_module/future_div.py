

def div_int_future():
    return 1 / 2


def div_float_future():
    return 3.14 / 0.125
