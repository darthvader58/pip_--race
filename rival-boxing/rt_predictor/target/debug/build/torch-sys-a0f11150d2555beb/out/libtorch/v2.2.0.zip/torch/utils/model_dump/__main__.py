#!/usr/bin/env python3
import sys
from . import main

sys.exit(main(sys.argv))
