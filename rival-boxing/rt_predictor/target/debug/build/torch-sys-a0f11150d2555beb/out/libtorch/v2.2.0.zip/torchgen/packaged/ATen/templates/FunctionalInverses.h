#pragma once

// ${generated_comment}

#include <ATen/Tensor.h>

namespace at {
namespace functionalization {

struct FunctionalInverses {

${view_inverse_declarations}

};
}
}
