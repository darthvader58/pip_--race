#pragma once

// ${generated_comment}

namespace at {
    // Enum of valid tags obtained from the entries in tags.yaml
    enum class Tag {
        ${enum_of_valid_tags}
    };
}
